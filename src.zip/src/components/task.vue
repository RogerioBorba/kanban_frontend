<template>
  <v-app>
    <v-layout row wrap>
      <v-flex xs3>
        <v-card class="primary yellow darken-3">
          <v-card-text class="px-0">A fazer</v-card-text>
          <v-btn icon v-tooltip:top="{ html: 'Incluir uma nova tarefa' }" @click="itemToDoAddClicked">
                <v-icon class="white--text">add</v-icon>
          </v-btn>
          <form  class="ma-2" v-show="hasToAddNewTask">
          
            <v-text-field label="Nome da tarefa" v-model="name"  required ></v-text-field>
            <v-text-field label="Descrição da tarefa" v-model="description"></v-text-field>
            <v-select label="Responsável" v-model="user_object" :items="user_list" item-text="username" @blur="blurSelectedUser" required></v-select>
            <v-flex xs12 sm6>
                 <v-menu lazy  :close-on-content-click="true"  v-model="menu"  transition="scale-transition" offset-y full-width  :nudge-left="40" max-width="290px">
                   <v-text-field slot="activator" label="Escolha a data no menu" v-model="started" prepend-icon="event" readonly ></v-text-field>
                   <v-date-picker v-model="started" no-title scrollable actions>
                   </v-date-picker>
                 </v-menu>
            </v-flex>
            <v-flex xs12 sm6>
                 <v-menu lazy  :close-on-content-click="true"  v-model="menu"  transition="scale-transition" offset-y full-width  :nudge-left="40" max-width="290px">
                   <v-text-field slot="activator" label="Escolha a data no menu" v-model="due" prepend-icon="event" readonly ></v-text-field>
                   <v-date-picker v-model="due" no-title scrollable actions>
                   </v-date-picker>
                 </v-menu>
            </v-flex>
            <v-select label="Sprint" v-model="sprint_object" :items="sprint_list" item-text="username" @blur="blurSelectedSprint" required></v-select>

            <v-btn round primary dark @click="confirmCreateNewTask">Confirmar</v-btn>
            <v-btn round primary dark @click="cancelCreateNewTask">Cancelar</v-btn>

           </form>
        </v-card>
        <v-card class="secondary ma-1 amber lighten-4"  v-for="(item, index) in cards_to_do" :key="index">
          <v-card-text class="px-0">{{item.name}}</v-card-text>
        </v-card>
      </v-flex>
      <v-flex xs3>
        <v-card class="primary">
          <v-card-text class="px-0">Fazendo</v-card-text>
        </v-card>
        <v-card class="secondary ma-1  indigo lighten-4"  v-for="(card, index) in cards_doing" :key="index">
          <v-card-text class="px-0">
            <div class="ma-0">
              <span style="float:left">{{card.started}} </span>
              <span style="float:right">{{card.responsible}} </span>
            </div>
          </v-card-text>
          <v-card-text class="px-0">
            <div class="ma-0">
              <span style="float:center">{{card.name}} </span>
            </div>
          </v-card-text>
          <v-card-actions>
            <v-btn icon v-tooltip:top="{ html: 'Editar tarefa' }">
                  <v-icon class="white--text">edit</v-icon>
            </v-btn>
            <v-btn icon v-tooltip:top="{ html: 'Remover tarefa' }" @click="itemDoingDeleteClicked(card, index)">
                  <v-icon class="white--text">delete</v-icon>
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn icon v-tooltip:top="{ html: 'Detalhes da tarefa'}" @click.native="itemDoingDetailClicked(card, index)">
                <v-icon class="white--text">{{card.arrowDetail}}</v-icon>
            </v-btn>
          </v-card-actions>
          <v-slide-y-transition>
            <v-card-text v-show="card.showDetail"> {{card.description}}</v-card-text>
          </v-slide-y-transition>
        </v-card>
      </v-flex>
      <v-flex xs3>
        <v-card class="green">
          <v-card-text class="px-0">Feito</v-card-text>
        </v-card>
        <v-card class="secondary ma-1 green lighten-4"  v-for="(item, index) in cards_done" :key="index">
          <v-card-text class="px-0">{{item.name}}</v-card-text>
        </v-card>
      </v-flex>
      <v-flex xs3>
        <v-card class="red">
          <v-card-text class="px-0">Pendente</v-card-text>
        </v-card>
        <v-card class="secondary ma-1 deep-orange lighten-4"  v-for="(item, index) in cards_pending" :key="index">
          <v-card-text class="px-0">{{item.name}}</v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
</v-app>
</template>
<script>
import {config} from './config';
import axios from 'axios';
export default {
  name: 'Tarefa',
  data() {
    return {
      url: '',
      items: [],
      cards_to_do: [],
      cards_doing: [],
      cards_done: [],
      cards_pending: [],
      actualItem: null,
      hasToAddNewTask: false,
      menu: false,
      name: null,
      description: null,
      status: 1,
      user_object: null,
      user_list: [],
      username: null,
      started: null,
      due: null,
      sprint: null,
      sprint_object: null,
      sprint_list: [],
      username: null,
    }
  },
  methods: {
    itemDetail(cards, anItem, index) {
        let  nCard = {};
        nCard.impediments= anItem.inpediments;
        nCard.id= anItem.id
        nCard.name = anItem.name;
        nCard.description = anItem.description;
        nCard.status = anItem.status;
        nCard.order = anItem.order;
        nCard.started = anItem.started;
        nCard.due = anItem.due;
        nCard.completed = anItem.completed;
        nCard.sprint = anItem.sprint;
        nCard.responsible = anItem.responsible;
        nCard.showDetail = !anItem.showDetail;
        nCard.arrowDetail =  !anItem.showDetail? 'keyboard_arrow_down' : 'keyboard_arrow_up';
        cards.splice(index,1, nCard);
        this.actualItem = nCard;
    },
    itemToDoDetailClicked(anItem, index) {
        this.itemDetail(this.cards_to_do, anItem, index)
    },
    itemDoingDetailClicked(anItem, index) {
        this.itemDetail(this.cards_doing, anItem, index)
    },
    itemDoneDetailClicked(anItem, index) {
        this.itemDetail(this.cards_done, anItem, index)
    },
    itemPendingClicked(anItem, index) {
        this.itemDetail(this.cards_pending, anItem, index)
    },
    itemToDoAddClicked() {
      console.log("new card");
      this.hasToAddNewTask = true;
    },

    itemToDoDeleteClicked(card, index) {},
    itemDoingDeleteClicked(card, index) {console.log("deleting..");},
    itemPendingDeleleteClicked(card, index) {},

    itemToDoEditClicked(card, index) {},
    itemDoingEditClicked(card, index) {},
    itemPendingEditClicked(card, index) {},

    confirmCreateNewTask() {
        this.hasToAddNewTask= false;
    },
    cancelCreateNewTask() {
        this.hasToAddNewTask= false;
    },

  },
  created: function () {
        this.url = "tasks/";
        axios.get(this.url).then(response => {
                this.items = response.data;
                this.items.forEach((anItem, idx) => {
                    let card = {impediments:[], id: anItem.id ,name:anItem.name, description: anItem.description, status:anItem.status, order:anItem.order, started:anItem.started, due:anItem.due,completed:anItem.completed, sprint:anItem.sprint, responsible:anItem.responsible, showDetail: false, arrowDetail: 'keyboard_arrow_down'};
                    if (anItem.status == 1)
                      this.cards_to_do.push(card);
                    else if (anItem.status == 2)
                      this.cards_doing.push(card);
                    else if (anItem.status == 3)
                      this.cards_done.push(card);
                    else {
                      this.cards_pending.push(card);
                    }
                });
        })
        .catch(error => {
          console.log(error);
        });
    }
}

</script>
