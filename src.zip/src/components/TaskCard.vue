<template>
<v-flex xs6 sm4 md3>
    <v-card :class="tabColor">
      <v-card-text class="text-xs-center black--text" >{{name}}
        <v-btn icon color="blue darken-2" v-if='add' @click.native="addTask">
          <v-icon color="white">add</v-icon>
        </v-btn>
      </v-card-text>
        <v-layout row wrap style="display:block;">
        <draggable v-model="tasks" :options="{group:'task'}" @add="changeStatus" :move="getElement">
          <transition-group tag="div" class="dragArea">
            <div v-for="(item, index) in filter()" :key="index">
              <v-flex xs12 class="mb-1" >
                <v-card class="secondary ma-1 dark" >
                  <v-card-title>
                      <span>{{item.started}}</span><br>
                      <span>{{item.responsible}}</span>
                      <span>{{item.name}}</span><br>
                  </v-card-title>
                  <v-card-actions>
                    <v-btn icon  @click="itemEditClicked(item)">
                          <v-icon dark color="yellow lighten-3">edit</v-icon>
                    </v-btn>
                    <v-btn icon  @click="removeTask(item)">
                          <v-icon dark color="red lighten-2">delete</v-icon>
                    </v-btn>
                  </v-card-actions>
                </v-card >
              </v-flex>
            </div>
          </transition-group>
        </draggable>
        </v-layout>
    </v-card>
</v-flex>
</template>

<script>
import { mapGetters } from 'vuex';
import { config, store } from './config';
import axios from 'axios';
import draggable from 'vuedraggable';

export default {

  props:[
    'add',
  	'tabColor',
  	'name',
    'cardColor',
    'status',
  ],

  components:{
    'draggable': draggable

 },

  data: () => ({
    tasksUrl: 'task-list/',
    users: [],
  }),

  methods: {

    getElement(evt){
      this.$store.commit('set_current_task', evt.draggedContext.element)
    },
    filter() {
      //console.log(this.tasks);
      return this.tasks.filter(a_task => a_task.status==this.status)
    },
    changeStatus (evt){

      console.log(evt);
      let temp_draggable = this.temp_task;
      let url = `${this.tasksUrl}${temp_draggable.id}/`;
      let  invalid =  'STATUS INVALIDO';
      let res = this.name =="A fazer" ? temp_task.status = 1:
        this.name =="Fazendo" ? temp_draggable.status = 2:
          this.name ==="Pendente" ? temp_draggable.status = 3:
            this.name == "Feito" ? temp_draggable.status = 4 :  invalid;
      if  (res ==  ~invalid)
        return console.log(invalid);
      axios.put(url, temp_draggable).then(res => this.$store.commit('clear_current_task'))
    },

    userById (url) {
      let name = '';
      let id = url.split('/').reverse()[1];
      this.usersList.map( user => user.id == id ? name = user.name : null);
      return name;
    },

    projectById (url) {
      let name = '';
      let id = url.split('/').reverse()[1];
      this.projectsList.map( project => project.id == id ? name = project.name : null);
      return name;
    },

    sprintById (url) {
      let name = '';
      let id = url.split('/').reverse()[1];
      this.sprintsList.map( sprint => sprint.id == id ? name = sprint.code : null);
      return name;
    },

    reverseDate (date) {
      return date.split('-').reverse().join('/');
    },
    addTask(){
      this.$store.commit('set_current_task', {});
      this.$store.commit('set_current_component_name', 'tarefa');
    },
    itemEditClicked(task){
      this.$store.commit('set_current_task', task);
      this.$store.commit('set_current_component_name', 'tarefa');
    },
    removeTask(task){
      axios.delete(`${this.tasksUrl}${task.id}/`).then( res =>{
        this.$store.commit('set_current_component_name', 'tarefas');
        })
        .catch(error => {
          console.log(error);
        });
    }
  },

  computed:{
    ...mapGetters({
      temp_task : 'task',
      tasks: 'tasks'
    }),
  },
  created() {

  }
}
</script>

<style scoped>
.dragArea {
  min-height: 25px;
}
.icon:before {
  font-family: sans-serif;
}
.sortable-ghost {
  animation-duration: 3s;
  animation-iteration-count: infinite;
  animation-name: my-ghost;
}

@keyframes my-ghost {
  25% {
    transform: rotate(1deg);
    opacity: 0.5;
    margin-left: 5px;
  }
  50% {
    transform: rotate(0deg);
    opacity: 0.3;
    margin-left: 0px;
  }
  75% {
    transform: rotate(-1deg);
    opacity: 0.5;
    margin-right: 5px;
  }
  100% {
    transform: rotate(0deg);
    opacity: 0.3;
    margin-right: 0px;
  }
}
</style>
